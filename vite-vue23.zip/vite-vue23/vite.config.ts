import { defineConfig } from 'vite'
// import { createVuePlugin } from 'vite-plugin-vue2'

import vitePluginVue3 from '@vitejs/plugin-vue';
import vitePluginVue2 from '@vitejs/plugin-vue2';

import vue2Compiler from '@vue/compiler-sfc-vue2';
import vue3Compiler from '@vue/compiler-sfc-vue3';

// https://vitejs.dev/config/
export default defineConfig({
  // plugins: [createVuePlugin()],
  plugins: [
    isVue3()
      ? vitePluginVue3({
          include: [/\.vue$/, /\.md$/],
          compiler: vue3Compiler as any
        })
      : vitePluginVue2({
          include: [/\.vue$/, /\.md$/],
          compiler: vue2Compiler as any
        }),
  ]
})


// 判断是否为Vue3的函数，具体实现需要根据项目情况来定义
function isVue3() {
  // ...
  return true;
}