
import './style.css'

// import Vue from 'vue2.7'
import App from './App.vue'

// new Vue({
//     render: (h) => h(<any>App),
// }).$mount('#app')


import { createApp } from 'vue3'
createApp(App).mount('#app')