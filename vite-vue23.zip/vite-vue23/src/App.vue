<template>
  <div id="app">
    <h1>Hello, Vue 2!</h1>
  </div>
</template>

<script lang="ts">
export default {}
</script>

<style scoped>
h1 {
  color: #42b983;
}
</style>