import { defineConfig } from 'vitepress'
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx'
import { demoblockPlugin, demoblockVitePlugin } from 'vitepress-theme-demoblock'

export default defineConfig({
  base: '/ui-vue-charts/',
  title: 'ui-vue-charts 文档',
  layout: 'home',
  themeConfig: {
    nav: getNav(),
    socialLinks: [{ icon: 'github', link: '' }],
    sidebar: getSidebar(),
  },
  markdown: {
    config: (md) => {
      md.use(demoblockPlugin)
    }
  },
  vite: {
    plugins: [vueJsx(),demoblockVitePlugin()],
    resolve: {
      alias: {
        // '@alias': path.resolve(__dirname, '../')
      }
    }
  }
})

function getNav() {
  return [
    { text: '指南', link: '/guide/' },
    { text: '组件', link: 'https://www.baidu.com', target: '_self' },
  ]
}

function getSidebar() {
  return {
    // 当用户在 `指南` 目录页面下将会展示这个侧边栏
    '/guide/': [
      {
        text: '指南',
        items: [
          // This shows `/guide/index.md` page.
          { text: '介绍', link: '/guide/' }, // /guide/index.md
          { text: '快速上手', link: '/guide/install' }, // /guide/one.md
          { text: '架构设计', link: '/guide/design' } // /guide/two.md
        ]
      },
      {
        text: '基本组件',
        items: [
          // This shows `/config/index.md` page.
          { text: 'Button 按钮', link: '/guide/button' },
          { text: 'select 选择器', link: '/guide/select' },
          { text: 'Tag 标签', link: '/guide/tag' }
        ]
      },
      {
        text: '其他',
        items: [
          // This shows `/config/index.md` page.
          { text: 'Divider 分割线', link: '/components/divider' }
        ]
      }
    ],

    // 当用户在 `配置` 目录页面下将会展示这个侧边栏
    '/components/': [
      
    ]
  }
}

function getDemoblock() {
  return {
    '/': {
      'hide-text': 'Hide',
      'show-text': 'Expand',
      'copy-button-text': 'Copy',
      'copy-success-text': 'Copy success'
    },
    '/zh': {
      'hide-text': '隐藏代码',
      'show-text': '显示代码',
      'copy-button-text': '复制代码片段',
      'copy-success-text': '复制成功'
    }
  }
}