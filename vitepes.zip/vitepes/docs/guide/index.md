# 这是一个练手的 UI 库

## 安装

:::demo

```vue
<template>
  <pg-button>Default</pg-button>
  <pg-button type="primary">Primary</pg-button>
  <pg-button type="success">Success</pg-button>
  <pg-button type="danger">Danger</pg-button>
</template>
```

:::