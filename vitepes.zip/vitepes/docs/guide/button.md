# 我是 Button

:::demo

```vue
<template>
  <pg-button>Default</pg-button>
  <pg-button type="primary">Primary</pg-button>
  <pg-button type="success">Success</pg-button>
  <pg-button type="danger">Danger</pg-button>
</template>
```

:::
