const vue = require('rollup-plugin-vue')
const postcss = require('rollup-plugin-postcss')
const path = require('path')
const alias = require('@rollup/plugin-alias')
const resolve = require('@rollup/plugin-node-resolve')
const commonjs = require('@rollup/plugin-commonjs')

module.exports = {
  input: 'src/main.js',
  output: [
    {
      format: 'cjs',
      file: 'dist/index.cjs.js',
      sourcemap: false,
      exports: 'named'
    },
    {
      format: 'umd',
      name: 'VueButton',
      file: 'dist/index.umd.js',
      sourcemap: false,
      exports: 'named',
      globals: {
        vue: 'Vue'
      }
    }
  ],
  external: ['vue'],
  plugins: [
    resolve(),
    commonjs(),
    alias({
      entries: [
        { find: '@', replacement: path.resolve(__dirname, 'src') }
      ]
    }),
    vue({
      css: true,
      template: {
        isProduction: true
      }
    }),
    postcss({
      extract: true,
      minimize: true,
      modules: false
    })
  ]
}