import Button from '@/components/Button.vue'

// Export the Button component
export { Button }

// Export default as a plugin
export default {
  install: (app) => {
    app.component('VButton', Button)
  }
}
