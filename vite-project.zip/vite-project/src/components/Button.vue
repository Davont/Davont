<script setup>
defineProps({
  label: {
    type: String,
    default: 'Button'
  },
  type: {
    type: String,
    default: 'primary',
    validator: (value) => ['primary', 'secondary', 'danger'].includes(value)
  },
  disabled: {
    type: Boolean,
    default: false
  }
})
</script>

<template>
  <button 
    :class="['custom-button', `button-${type}`]"
    :disabled="disabled"
  >
    {{ label }}
  </button>
</template>

<style scoped>
.custom-button {
  padding: 8px 16px;
  border-radius: 4px;
  border: none;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s ease;
}

.custom-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.button-primary {
  background-color: #4CAF50;
  color: white;
}

.button-primary:hover:not(:disabled) {
  background-color: #45a049;
}

.button-secondary {
  background-color: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
}

.button-secondary:hover:not(:disabled) {
  background-color: #e8e8e8;
}

.button-danger {
  background-color: #f44336;
  color: white;
}

.button-danger:hover:not(:disabled) {
  background-color: #da190b;
}
</style>