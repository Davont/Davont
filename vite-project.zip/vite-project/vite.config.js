import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import postcss from 'rollup-plugin-postcss'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue(), postcss({
    extract: true,  // 将 CSS 提取到单独的文件
    minimize: true  // 压缩 CSS
  })],

})
