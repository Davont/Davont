"use client"

import { useState, useEffect } from "react"
import ReactDOM from "react-dom"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import { CopyIcon } from "lucide-react"
import SyntaxHighlighter from "react-syntax-highlighter"
import { vs2015 } from "react-syntax-highlighter/dist/esm/styles/hljs"

const Preview = ({ jsx, css }: { jsx: string; css: string }) => {
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      const jsxElement = eval(`(${jsx})`)
      ReactDOM.render(
        <div>
          <style>{css}</style>
          {jsxElement}
        </div>,
        document.getElementById("preview-container"),
      )
      setError(null)
    } catch (err) {
      setError(err.message)
    }
  }, [jsx, css])

  return (
    <div className="border rounded-md p-4 min-h-[300px]">
      {error ? <div className="text-red-500">Error: {error}</div> : <div id="preview-container" />}
    </div>
  )
}

export default function JsonToJsxCssGenerator() {
  const [jsonInput, setJsonInput] = useState("")
  const [generatedJsx, setGeneratedJsx] = useState("")
  const [generatedCss, setGeneratedCss] = useState("")
  const { toast } = useToast()

  const handleGenerate = () => {
    // 这里是生成 JSX 和 CSS 的逻辑
    // 为了演示，我们设置一些示例 JSX 代码
    setGeneratedJsx('<div className="example">Generated JSX</div>')
    setGeneratedCss(".example { color: blue; }")
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "The code has been copied to your clipboard.",
      })
    })
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-6">JSON to JSX/CSS Generator</h1>
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="w-full lg:w-1/2 space-y-4">
          <Textarea
            placeholder="Enter your JSON here..."
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            className="min-h-[400px]"
          />
          <Button onClick={handleGenerate} className="w-full">
            Generate JSX/CSS
          </Button>
        </div>
        <div className="w-full lg:w-1/2">
          <p className="text-sm text-gray-500 mb-2">Generated code and preview:</p>
          <Tabs defaultValue="jsx" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="jsx">JSX</TabsTrigger>
              <TabsTrigger value="css">CSS</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
            </TabsList>
            <TabsContent value="jsx" className="relative">
              <SyntaxHighlighter language="jsx" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-[300px]">
                {generatedJsx}
              </SyntaxHighlighter>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => copyToClipboard(generatedJsx)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
            <TabsContent value="css" className="relative">
              <SyntaxHighlighter language="css" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-[300px]">
                {generatedCss}
              </SyntaxHighlighter>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => copyToClipboard(generatedCss)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
            <TabsContent value="preview">
              <Preview jsx={generatedJsx} css={generatedCss} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Toaster />
    </div>
  )
}

