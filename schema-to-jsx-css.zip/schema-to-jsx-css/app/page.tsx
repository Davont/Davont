import SchemaConverter from "./components/SchemaConverter"

export default function Home() {
  return (
    <main className="min-h-screen">
      <SchemaConverter />
    </main>
  )
}

