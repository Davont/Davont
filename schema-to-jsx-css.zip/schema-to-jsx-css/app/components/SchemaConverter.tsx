 "use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import * as CodeGenerator from '../loader/standalone-loader';
import schemaExample from '../loader/example-schema.json';

export default function SchemaConverter() {
  const [schema, setSchema] = useState(JSON.stringify(schemaExample))
  const [generatedJSX, setGeneratedJSX] = useState("")
  const [generatedCSS, setGeneratedCSS] = useState("")
  console.log("schemaExample", schemaExample)

  const handleGenerate = async () => {
    try {
      // 提前初始化，这样后面用的时候更快
        await CodeGenerator.init();
        const result = await CodeGenerator.generateCode({
          workerJsUrl: "/standalone-worker.js", // 使用导入的 workerJsUrl
          solution: 'icejs', // 出码方案 (目前内置有 icejs、icejs3 和 rax )
          schema, // 编排搭建出来的 schema
          flattenResult: true, // 是否生成扁平结构的结果
        });

        console.log("出码：", result); // 出码结果
        setGeneratedJSX(result[27].content)
        setGeneratedCSS(result[28].content)
    } catch (error) {
      console.error("生成代码时出错：", error);
      setGeneratedJSX('')
      setGeneratedCSS('')
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <h1 className="text-3xl font-semibold text-center mb-8">Schema to JSX/CSS Converter</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <Textarea
            className="min-h-[400px] w-full p-4 text-sm border-gray-200 rounded-md resize-none focus:ring-2 focus:ring-primary"
            placeholder="Enter your JSON schema here..."
            value={schema}
            onChange={(e) => setSchema(e.target.value)}
          />
          <Button onClick={handleGenerate} className="w-full">
            Generate Code
          </Button>
        </div>
        <div className="space-y-4">
          <Tabs defaultValue="jsx" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="jsx" className="text-sm">
                JSX
              </TabsTrigger>
              <TabsTrigger value="css" className="text-sm">
                CSS
              </TabsTrigger>
            </TabsList>
            <TabsContent value="jsx">
              <Textarea
                className="min-h-[400px] w-full p-4 text-sm font-mono bg-gray-50 border-gray-200 rounded-md resize-none"
                placeholder="Generated JSX will appear here..."
                value={generatedJSX}
                readOnly
              />
            </TabsContent>
            <TabsContent value="css">
              <Textarea
                className="min-h-[400px] w-full p-4 text-sm font-mono bg-gray-50 border-gray-200 rounded-md resize-none"
                placeholder="Generated CSS will appear here..."
                value={generatedCSS}
                readOnly
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}