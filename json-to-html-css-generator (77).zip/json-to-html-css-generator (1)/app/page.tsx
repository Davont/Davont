"use client"

import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import { CopyIcon } from "lucide-react"
import SyntaxHighlighter from "react-syntax-highlighter"
import { vs2015 } from "react-syntax-highlighter/dist/esm/styles/hljs"
import * as CodeGenerator from './loader/standalone-loader';
import schemaExample from './loader/example-schema.json';

export default function JsonToHtmlCssGenerator() {
  const [jsonInput, setJsonInput] = useState(JSON.stringify(schemaExample))
  const [generatedHtml, setGeneratedHtml] = useState("")
  const [generatedCss, setGeneratedCss] = useState("")
  const { toast } = useToast()

  const handleGenerate = async () => {
    // 这里是生成 HTML 和 CSS 的逻辑
    // 为了演示,我们只是简单地设置一些示例代码
    try {
      // 提前初始化，这样后面用的时候更快
        await CodeGenerator.init();
        const result = await CodeGenerator.generateCode({
          workerJsUrl: "/standalone-worker.js", // 使用导入的 workerJsUrl
          solution: 'icejs', // 出码方案 (目前内置有 icejs、icejs3 和 rax )
          schema:jsonInput, // 编排搭建出来的 schema
          flattenResult: true, // 是否生成扁平结构的结果
        });

        console.log("出码：", result); // 出码结果
        setGeneratedHtml(result[27].content)
        setGeneratedCss(result[28].content)
    } catch (error) {
      console.error("生成代码时出错：", error);
      setGeneratedHtml('')
      setGeneratedCss('')
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "The code has been copied to your clipboard.",
      })
    })
  }

  return (
    <div className="container mx-auto p-4 h-screen flex flex-col">
      <h1 className="text-3xl font-bold text-center mb-6">JSON to HTML/CSS Generator</h1>
      <div className="flex flex-col lg:flex-row gap-6 flex-1 overflow-hidden">
        <div className="w-full lg:w-1/2 flex flex-col space-y-4">
          <Textarea
            placeholder="Enter your JSON here..."
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            className="flex-1 min-h-0 resize-none"
          />
          <Button onClick={handleGenerate} className="w-full">
            Generate HTML/CSS
          </Button>
        </div>
        <div className="w-full lg:w-1/2 flex flex-col">
          <Tabs defaultValue="html" className="w-full flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="html">HTML</TabsTrigger>
              <TabsTrigger value="css">CSS</TabsTrigger>
            </TabsList>
            <TabsContent value="html" className="relative flex-1 overflow-hidden">
              <div className="absolute inset-0 overflow-auto">
                <SyntaxHighlighter language="html" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-full">
                  {generatedHtml}
                </SyntaxHighlighter>
              </div>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2 z-10"
                onClick={() => copyToClipboard(generatedHtml)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
            <TabsContent value="css" className="relative flex-1 overflow-hidden">
              <div className="absolute inset-0 overflow-auto">
                <SyntaxHighlighter language="css" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-full">
                  {generatedCss}
                </SyntaxHighlighter>
              </div>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2 z-10"
                onClick={() => copyToClipboard(generatedCss)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Toaster />
    </div>
  )
}

