# ui-vue/charts
### 项目启动
安装依赖
```
pnpm i
```
库构建
```
turbo build
```
启动文档
```
pnpm -F docs  docs:dev
```
