import vue from 'rollup-plugin-vue';
import typescript from '@rollup/plugin-typescript';


export default {
  input: './index.ts',
  output: {
    format: 'esm',
    file: 'dist/my-library.vue2.js',
  },
  plugins: [
    vue({ template: { optimizeSSR: true }, version: 2 }),
    typescript()
  ],
};