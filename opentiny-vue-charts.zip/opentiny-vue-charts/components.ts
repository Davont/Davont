import ButtonInstall from 'opentiny-vue-charts/tag'
import TagInstall from 'opentiny-vue-charts/button'
import type { Plugin } from 'vue'

export default [ButtonInstall, TagInstall] as Plugin[]
