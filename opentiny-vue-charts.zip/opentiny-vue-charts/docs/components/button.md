# 我是 Button

:::demo 使用 `type` 属性来定义 Button 的样式。

```vue
<template>
  <pg-button>Default</pg-button>
  <pg-button type="primary">Primary</pg-button>
  <pg-button type="success">Success</pg-button>
  <pg-button type="danger">Danger</pg-button>
</template>
```

:::
