import DefaultTheme from 'vitepress/theme'
import TagInstall from 'opentiny-vue-charts/dist/tag/tag.esm.js'
import ButtonInstall  from 'opentiny-vue-charts/dist/button/button.esm.js'
import 'opentiny-vue-charts/styles/button.scss'
// 插件的组件，主要是demo组件
import './styles/index.css'
import 'vitepress-theme-demoblock/dist/theme/styles/index.css'
import Demo from 'vitepress-theme-demoblock/dist/client/components/Demo.vue'
import DemoBlock from 'vitepress-theme-demoblock/dist/client/components/DemoBlock.vue'
// import "uno.css"

// console.log(PgKit);
export default {
  ...DefaultTheme,
  enhanceApp({ app }) {
    app.use(ButtonInstall)
    app.use(TagInstall)
    app.component('Demo', Demo)
    app.component('DemoBlock', DemoBlock)
  }
}
