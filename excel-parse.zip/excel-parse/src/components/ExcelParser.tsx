import { useState, ChangeEvent } from 'react';
import * as XLSX from 'xlsx';
import './ExcelParser.css';

interface ExcelData {
  [key: string]: string | number;
}

interface ParsedJsonData {
  projectId?: number;
  pageId?: number;
  pageVersionId?: number;
  account?: string;
  date?: string;
  type?: string;
  lineCount?: number;
  [key: string]: any;
}

interface ProcessedItem {
  original: string;
  parsed: ParsedJsonData;
}

type ViewMode = 'card' | 'table' | 'original';

const ExcelParser = () => {
  const [data, setData] = useState<ExcelData[]>([]);
  const [columnNames, setColumnNames] = useState<string[]>([]);
  const [selectedColumn, setSelectedColumn] = useState<string>('');
  const [extractedData, setExtractedData] = useState<string[]>([]);
  const [parsedJsonData, setParsedJsonData] = useState<ProcessedItem[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [isJsonData, setIsJsonData] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<ViewMode>('card');

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const binaryString = event.target?.result;
        const workbook = XLSX.read(binaryString, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const parsedData = XLSX.utils.sheet_to_json<ExcelData>(worksheet);
        
        setData(parsedData);
        
        // 获取所有列名
        if (parsedData.length > 0) {
          const columns = Object.keys(parsedData[0]);
          setColumnNames(columns);
        }
      } catch (error) {
        console.error('解析Excel文件时出错:', error);
        alert('解析Excel文件时出错，请确保文件格式正确');
      }
    };
    
    reader.readAsBinaryString(file);
  };

  const handleColumnSelect = (e: ChangeEvent<HTMLSelectElement>) => {
    const column = e.target.value;
    setSelectedColumn(column);
    
    if (column && data.length > 0) {
      // 提取选定列的数据
      const extracted = data.map(row => String(row[column] || '')).filter(Boolean);
      setExtractedData(extracted);
      
      // 尝试解析JSON字符串
      try {
        const firstItem = extracted[0];
        
        // 检查是否可能是JSON字符串
        if (firstItem) {
          // 尝试处理转义的JSON字符串
          const processedItems = extracted.map(item => {
            try {
              // 去除前后的引号（如果有）
              let processedStr = item;
              if (processedStr.startsWith('"') && processedStr.endsWith('"')) {
                processedStr = processedStr.substring(1, processedStr.length - 1);
              }
              
              // 替换所有转义的引号 \" 为正常引号 "
              processedStr = processedStr.replace(/\\"/g, '"');
              
              // 修复可能存在的特殊情况，如 pageId\ " 这样的错误格式
              processedStr = processedStr.replace(/\\[\s]*"/g, '"');
              
              // 解析为JSON对象
              const jsonObj = JSON.parse(processedStr);
              return { original: item, parsed: jsonObj };
            } catch (e) {
              let errorMessage = '解析JSON时出错:';
              let errorDetails = e instanceof Error ? e.message : String(e);
              console.error(errorMessage, errorDetails, '原始字符串:', item);
              return null;
            }
          }).filter(Boolean) as ProcessedItem[];
          
          if (processedItems.length > 0) {
            setIsJsonData(true);
            setParsedJsonData(processedItems);
            // 默认使用表格视图
            setViewMode('table');
          } else {
            setIsJsonData(false);
            setParsedJsonData([]);
          }
        } else {
          setIsJsonData(false);
          setParsedJsonData([]);
        }
      } catch (error) {
        console.error('检测JSON数据时出错:', error);
        setIsJsonData(false);
        setParsedJsonData([]);
      }
    } else {
      setExtractedData([]);
      setIsJsonData(false);
      setParsedJsonData([]);
    }
  };

  // 切换显示模式
  const changeViewMode = (mode: ViewMode) => {
    setViewMode(mode);
  };

  // 获取所有JSON对象的所有可能键
  const getAllKeys = (): string[] => {
    if (parsedJsonData.length === 0) return [];
    
    // 收集所有对象中的所有键
    const keysSet = new Set<string>();
    parsedJsonData.forEach(item => {
      Object.keys(item.parsed).forEach(key => keysSet.add(key));
    });
    
    return Array.from(keysSet);
  };

  // 格式化JSON对象显示（卡片视图）
  const renderJsonObject = (obj: ParsedJsonData) => {
    return (
      <div className="json-object">
        {Object.entries(obj).map(([key, value]) => (
          <div key={key} className="json-property">
            <span className="json-key">{key}:</span>
            <span className="json-value">{String(value)}</span>
          </div>
        ))}
      </div>
    );
  };

  // 渲染表格视图
  const renderTableView = () => {
    const allKeys = getAllKeys();
    
    return (
      <div className="table-container">
        <table className="json-table">
          <thead>
            <tr>
              <th>#</th>
              {allKeys.map(key => (
                <th key={key}>{key}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {parsedJsonData.map((item, index) => (
              <tr key={index}>
                <td className="row-index">{index + 1}</td>
                {allKeys.map(key => (
                  <td key={key}>
                    {item.parsed[key] !== undefined ? String(item.parsed[key]) : '-'}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  // 生成示例数据
  const generateSampleData = () => {
    const sampleData: ExcelData[] = [
      {
        id: 1,
        name: "示例1",
        jsonData: "{\"projectId\":4896,\"pageId\":30239,\"pageVersionId\":37240,\"account\":\"xxxx123123\",\"date\":\"2024/12/9 19:12:34\",\"type\":\"Connected\",\"lineCount\":151}"
      },
      {
        id: 2,
        name: "示例2",
        jsonData: "{\"projectId\":4897,\"pageId\":30240,\"pageVersionId\":37241,\"account\":\"yyyy456456\",\"date\":\"2024/12/10 10:15:22\",\"type\":\"Disconnected\",\"lineCount\":98}"
      },
      {
        id: 3,
        name: "示例3",
        jsonData: "{\"projectId\":4898,\"pageId\\\":30241,\"pageVersionId\":37242,\"account\":\"zzzz789789\",\"date\":\"2024/12/11 14:30:45\",\"type\":\"Connected\",\"lineCount\":205}"
      }
    ];

    setData(sampleData);
    setFileName("示例数据.xlsx");
    setColumnNames(Object.keys(sampleData[0]));
    setSelectedColumn('');
    setExtractedData([]);
    setIsJsonData(false);
    setParsedJsonData([]);
  };

  return (
    <div className="excel-parser">
      <h2>Excel文件解析器</h2>
      
      <div className="upload-section">
        <label htmlFor="file-upload" className="upload-label">
          选择Excel文件
          <input
            id="file-upload"
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileUpload}
            className="file-input"
          />
        </label>
        <button onClick={generateSampleData} className="sample-data-btn">
          生成示例数据
        </button>
        {fileName && <p className="file-name">已选择: {fileName}</p>}
      </div>

      {columnNames.length > 0 && (
        <div className="column-select-section">
          <label htmlFor="column-select">选择要提取的列:</label>
          <select
            id="column-select"
            value={selectedColumn}
            onChange={handleColumnSelect}
            className="column-select"
          >
            <option value="">-- 请选择列 --</option>
            {columnNames.map((column, index) => (
              <option key={index} value={column}>
                {column}
              </option>
            ))}
          </select>
        </div>
      )}

      {isJsonData && parsedJsonData.length > 0 ? (
        <div className="results-section">
          <div className="results-header">
            <h3>解析的JSON数据 (来自列: {selectedColumn})</h3>
            <div className="view-controls">
              <button 
                onClick={() => changeViewMode('table')} 
                className={`view-btn ${viewMode === 'table' ? 'active' : ''}`}
              >
                表格视图
              </button>
              <button 
                onClick={() => changeViewMode('card')} 
                className={`view-btn ${viewMode === 'card' ? 'active' : ''}`}
              >
                卡片视图
              </button>
              <button 
                onClick={() => changeViewMode('original')} 
                className={`view-btn ${viewMode === 'original' ? 'active' : ''}`}
              >
                原始数据
              </button>
            </div>
          </div>

          {viewMode === 'table' && renderTableView()}

          {viewMode === 'card' && (
            <div className="json-data-list">
              {parsedJsonData.map((item, index) => (
                <div key={index} className="json-data-item">
                  <h4>对象 #{index + 1}</h4>
                  {renderJsonObject(item.parsed)}
                </div>
              ))}
            </div>
          )}

          {viewMode === 'original' && (
            <div className="json-data-list">
              {parsedJsonData.map((item, index) => (
                <div key={index} className="json-data-item">
                  <div className="original-data">
                    <h4>原始字符串 #{index + 1}:</h4>
                    <pre>{item.original}</pre>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : extractedData.length > 0 && (
        <div className="results-section">
          <h3>提取的数据 (来自列: {selectedColumn})</h3>
          <div className="data-list">
            {extractedData.map((item, index) => (
              <div key={index} className="data-item">
                {item}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExcelParser;