import './App.css'
import ExcelParser from './components/ExcelParser'
import { Layout, Typography, Divider } from '@douyinfe/semi-ui'

const { Header, Content, Footer } = Layout
const { Title, Text } = Typography

function App() {
  return (
    <Layout className="app-layout">
      <Header className="app-header">
        <Title heading={2} style={{ color: 'white', margin: 0 }}>
          Excel解析工具
        </Title>
        <Text style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
          上传Excel文件并提取特定列的JSON数据
        </Text>
      </Header>
      <Content className="app-content">
        <ExcelParser />
      </Content>
      <Footer className="app-footer">
        <Divider />
        <Text type="quaternary">© {new Date().getFullYear()} Excel解析工具</Text>
      </Footer>
    </Layout>
  )
}

export default App
