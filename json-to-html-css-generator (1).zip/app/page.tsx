"use client"

import React, { useState, useEffect } from "react"
import ReactDOM from "react-dom/client"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/components/ui/use-toast"
import { CopyIcon } from "lucide-react"
import SyntaxHighlighter from "react-syntax-highlighter"
import { vs2015 } from "react-syntax-highlighter/dist/esm/styles/hljs"
import less from "less"
import Sass from "sass.js/dist/sass.js"

const Preview = ({ jsx, css, cssType }: { jsx: string; css: string; cssType: "css" | "less" | "sass" }) => {
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const renderPreview = async () => {
      try {
        const createElementFromJSX = (jsxString: string) => {
          // 处理自闭合标签
          if (jsxString.match(/<(\w+)([^>]*)\/>$/)) {
            const [, tagName, attributesString] = jsxString.match(/<(\w+)([^>]*)\/>$/)!
            const attributes: { [key: string]: string } = {}
            const attributeMatches = attributesString.matchAll(/(\w+)="([^"]*)"/g)
            for (const match of attributeMatches) {
              attributes[match[1]] = match[2]
            }
            return React.createElement(tagName, attributes)
          }

          // 处理普通标签
          const elementMatch = jsxString.match(/<(\w+)([^>]*)>(.*?)<\/\1>/)
          if (!elementMatch) {
            throw new Error("Invalid JSX string")
          }

          const [, tagName, attributesString, children] = elementMatch
          const attributes: { [key: string]: string } = {}
          const attributeMatches = attributesString.matchAll(/(\w+)="([^"]*)"/g)
          for (const match of attributeMatches) {
            attributes[match[1]] = match[2]
          }

          return React.createElement(tagName, attributes, children)
        }

        const jsxElement = createElementFromJSX(jsx)
        const previewContainer = document.getElementById("preview-container")
        if (previewContainer) {
          previewContainer.innerHTML = "" // 清除之前的内容
          const styleElement = document.createElement("style")

          // 处理不同类型的 CSS
          let processedCss = css
          if (cssType === "less") {
            const output = await less.render(css)
            processedCss = output.css
          } else if (cssType === "sass") {
            await new Promise<void>((resolve, reject) => {
              Sass.compile(css, (result) => {
                if (result.status === 0) {
                  processedCss = result.text
                  resolve()
                } else {
                  reject(new Error(result.formatted))
                }
              })
            })
          }

          styleElement.textContent = processedCss
          previewContainer.appendChild(styleElement)
          const root = ReactDOM.createRoot(previewContainer)
          root.render(jsxElement)
        }
        setError(null)
      } catch (err) {
        setError(err.message)
      }
    }

    renderPreview()
  }, [jsx, css, cssType])

  return (
    <div className="border rounded-md p-4 min-h-[300px]">
      {error ? <div className="text-red-500">Error: {error}</div> : <div id="preview-container" />}
    </div>
  )
}

export default function JsonToJsxCssGenerator() {
  const [jsonInput, setJsonInput] = useState("")
  const [generatedJsx, setGeneratedJsx] = useState("")
  const [generatedCss, setGeneratedCss] = useState("")
  const [cssType, setCssType] = useState<"css" | "less" | "sass">("css")
  const { toast } = useToast()

  const handleGenerate = () => {
    // 这里是生成 JSX 和 CSS 的逻辑
    // 为了演示，我们设置一些示例 JSX 和 CSS 代码
    setGeneratedJsx('<div className="example"><h1>Generated JSX</h1><p>This is a paragraph.</p></div>')
    setGeneratedCss(`
      .example {
        background-color: #f0f0f0;
        padding: 20px;
        border-radius: 8px;
        
        h1 {
          color: #333;
          font-size: 24px;
        }
        
        p {
          color: #666;
          font-size: 16px;
        }
      }
    `)
    setCssType("sass") // 或 'less'，取决于您想要演示哪种
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "The code has been copied to your clipboard.",
      })
    })
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-6">JSON to JSX/CSS Generator</h1>
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="w-full lg:w-1/2 space-y-4">
          <Textarea
            placeholder="Enter your JSON here..."
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            className="min-h-[400px]"
          />
          <Button onClick={handleGenerate} className="w-full">
            Generate JSX/CSS
          </Button>
        </div>
        <div className="w-full lg:w-1/2">
          <p className="text-sm text-gray-500 mb-2">Generated code and preview:</p>
          <Tabs defaultValue="jsx" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="jsx">JSX</TabsTrigger>
              <TabsTrigger value="css">CSS</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="cssType">CSS Type</TabsTrigger>
            </TabsList>
            <TabsContent value="jsx" className="relative">
              <SyntaxHighlighter language="jsx" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-[300px]">
                {generatedJsx}
              </SyntaxHighlighter>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => copyToClipboard(generatedJsx)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
            <TabsContent value="css" className="relative">
              <SyntaxHighlighter language="css" style={vs2015} className="!bg-gray-800 rounded-md p-4 min-h-[300px]">
                {generatedCss}
              </SyntaxHighlighter>
              <Button
                variant="outline"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => copyToClipboard(generatedCss)}
              >
                <CopyIcon className="h-4 w-4" />
              </Button>
            </TabsContent>
            <TabsContent value="preview">
              <Preview jsx={generatedJsx} css={generatedCss} cssType={cssType} />
            </TabsContent>
            <TabsContent value="cssType">
              <div className="space-y-2">
                <Button
                  onClick={() => setCssType("css")}
                  variant={cssType === "css" ? "default" : "outline"}
                  className="w-full"
                >
                  CSS
                </Button>
                <Button
                  onClick={() => setCssType("less")}
                  variant={cssType === "less" ? "default" : "outline"}
                  className="w-full"
                >
                  Less
                </Button>
                <Button
                  onClick={() => setCssType("sass")}
                  variant={cssType === "sass" ? "default" : "outline"}
                  className="w-full"
                >
                  Sass
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Toaster />
    </div>
  )
}

